#!/bin/bash -euo pipefail
(cd 'index'; sha256sum -c checksums.sha256)
bwa-mem2 mem -t 14 -R '@RG\tID:SRR4000468\tSM:atac-arabidopsis-depth-1000000\tLB:SRR4000468' 'index/genome.fa' 'analysis_R1.fastq.gz' 'analysis_R2.fastq.gz' |
  samtools sort -n -m 128M -o query.bam
samtools fixmate -m query.bam fixed.bam
samtools sort -m 128M -o coordinate.bam fixed.bam
samtools markdup -s coordinate.bam marked.bam 2> duplicate-marking.txt
samtools index marked.bam
samtools flagstat marked.bam > raw.flagstat.txt
samtools stats marked.bam > raw.stats.txt
samtools idxstats marked.bam > raw.idxstats.txt
{ bwa-mem2 version; samtools --version; } > alignment.versions.txt
