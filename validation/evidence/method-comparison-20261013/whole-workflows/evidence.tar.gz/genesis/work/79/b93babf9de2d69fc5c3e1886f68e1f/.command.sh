#!/bin/bash -euo pipefail
python - <<'PY'
import pyBigWig
sizes = [line.split() for line in open('chrom.sizes')]
with pyBigWig.open('cuts.counts.bw', 'w') as target:
    target.addHeader([(chrom, int(n)) for chrom, n in sorted(sizes)])
    batch = []
    def flush():
        if batch:
            target.addEntries([r[0] for r in batch], [int(r[1]) for r in batch],
                              ends=[int(r[2]) for r in batch], values=[float(r[3]) for r in batch])
            batch.clear()
    for line in open('cuts.bedgraph'):
        batch.append(line.split())
        if len(batch) >= 16384:
            flush()
    flush()
PY
