#!/bin/bash -euo pipefail
export XDG_CACHE_HOME="$PWD/.cache"
fastqc --threads 1 --memory 512 --noextract 'raw_R1.fastq.gz'
test -s raw_R1_fastqc.zip
test -s raw_R1_fastqc.html
