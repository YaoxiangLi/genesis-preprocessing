#!/bin/bash -euo pipefail
export XDG_CACHE_HOME="$PWD/.cache"
printf '%s\n' 'data_dir_name: multiqc_data' > multiqc_config.yaml
multiqc . --force --require-logs -m fastqc -m samtools --filename multiqc_report.html --data-dir --data-format json --config multiqc_config.yaml
PYTHONPATH='code-014ff33475b9df6ee8512d7f58d9cc41c6c6200e407c5a632b5e4c1348df5b35' python -m genesis_tools.atac.stages report
