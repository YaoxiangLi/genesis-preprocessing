#!/bin/bash -euo pipefail
mkdir index
gzip -dc input.fa.gz > index/genome.fa
samtools faidx index/genome.fa
cut -f1,2 index/genome.fa.fai > index/chrom.sizes
bwa-mem2 index index/genome.fa
bwa-mem2 version > index/bwa.version.txt
(cd index; sha256sum genome.fa* chrom.sizes bwa.version.txt > checksums.sha256)
