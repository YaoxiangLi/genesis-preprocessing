#!/bin/bash -euo pipefail
ln -s 'raw_R1.fastq.gz' analysis_R1.fastq.gz; ln -s 'raw_R2.fastq.gz' analysis_R2.fastq.gz; printf '%s\n' '{"policy":"none"}' > adapters.json
