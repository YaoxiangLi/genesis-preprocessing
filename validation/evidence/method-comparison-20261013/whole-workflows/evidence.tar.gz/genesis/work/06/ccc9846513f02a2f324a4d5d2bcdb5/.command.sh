#!/bin/bash -euo pipefail
macs3 callpeak -t 'usable.bam' -f BAMPE -g 118960141 -q 0.01 --keep-dup all -n atac
macs3 --version > macs3.version.txt
