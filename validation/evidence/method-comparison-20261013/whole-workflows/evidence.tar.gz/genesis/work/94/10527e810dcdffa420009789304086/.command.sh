#!/bin/bash -euo pipefail
export XDG_CACHE_HOME="$PWD/.cache"
fastqc --threads 1 --memory 512 --noextract 'raw_R2.fastq.gz'
test -s raw_R2_fastqc.zip
test -s raw_R2_fastqc.html
