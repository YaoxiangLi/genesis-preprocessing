#!/bin/bash -euo pipefail
PYTHONPATH='code-014ff33475b9df6ee8512d7f58d9cc41c6c6200e407c5a632b5e4c1348df5b35' python -m genesis_tools.atac.stages acquire --manifest 'SRR4000468.json'
