#!/bin/bash -euo pipefail
samtools \
    idxstats \
    --threads 13 \
    SRR4000468_REP1.mLb.clN.sorted.bam \
    > SRR4000468_REP1.mLb.clN.sorted.bam.idxstats

cat <<-END_VERSIONS > versions.yml
"NFCORE_ATACSEQ:ATACSEQ:MERGED_LIBRARY_FILTER_BAM:BAM_SORT_STATS_SAMTOOLS:BAM_STATS_SAMTOOLS:SAMTOOLS_IDXSTATS":
    samtools: $(echo $(samtools --version 2>&1) | sed 's/^.*samtools //; s/Using.*$//')
END_VERSIONS
