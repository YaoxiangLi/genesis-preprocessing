#!/bin/bash -euo pipefail
# Not calling gunzip itself because it creates files
# with the original group ownership rather than the
# default one for that user / the work directory
gzip \
    -cd \
     \
    arabidopsis.gtf.gz.asset.gtf.gz \
    > arabidopsis.gtf.asset.gtf.gz

cat <<-END_VERSIONS > versions.yml
"NFCORE_ATACSEQ:ATACSEQ:PREPARE_GENOME:GUNZIP_GTF":
    gunzip: $(echo $(gunzip --version 2>&1) | sed 's/^.*(gzip) //; s/ Copyright.*$//')
END_VERSIONS
