#!/bin/bash -euo pipefail
samtools \
    stats \
    --threads 14 \
    --reference reference.fa \
    SRR4000468_REP1.mLb.mkD.sorted.bam \
    > SRR4000468_REP1.mLb.mkD.sorted.bam.stats

cat <<-END_VERSIONS > versions.yml
"NFCORE_ATACSEQ:ATACSEQ:MERGED_LIBRARY_MARKDUPLICATES_PICARD:BAM_STATS_SAMTOOLS:SAMTOOLS_STATS":
    samtools: $(echo $(samtools --version 2>&1) | sed 's/^.*samtools //; s/Using.*$//')
END_VERSIONS
