#!/bin/bash -euo pipefail
awk '{print $1, '0' , $2}' OFS='	' reference.fa.sizes | awk '$1 !~ /Mt/ {print $0}' > reference.include_regions.bed

cat <<-END_VERSIONS > versions.yml
"NFCORE_ATACSEQ:ATACSEQ:PREPARE_GENOME:GENOME_BLACKLIST_REGIONS":
    bedtools: $(bedtools --version | sed -e "s/bedtools v//g")
END_VERSIONS
