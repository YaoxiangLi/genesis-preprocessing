#!/bin/bash -euo pipefail
macs2 \
    callpeak \
    --keep-dup all --nomodel --qvalue 0.01 \
    --gsize 119667750 \
    --format BAMPE \
    --name SRR4000468_REP1.mLb.clN \
    --treatment SRR4000468_REP1.mLb.clN.sorted.bam \


cat <<-END_VERSIONS > versions.yml
"NFCORE_ATACSEQ:ATACSEQ:MERGED_LIBRARY_CALL_ANNOTATE_PEAKS:MACS2_CALLPEAK":
    macs2: $(macs2 --version | sed -e "s/macs2 //g")
END_VERSIONS
