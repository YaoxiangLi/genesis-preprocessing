#!/bin/bash -euo pipefail
samtools faidx reference.fa
cut -f 1,2 reference.fa.fai > reference.fa.sizes

cat <<-END_VERSIONS > versions.yml
"NFCORE_ATACSEQ:ATACSEQ:PREPARE_GENOME:CUSTOM_GETCHROMSIZES":
    getchromsizes: $(echo $(samtools --version 2>&1) | sed 's/^.*samtools //; s/Using.*$//')
END_VERSIONS
