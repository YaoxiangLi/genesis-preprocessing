#!/bin/bash -euo pipefail
cat SRR4000468_REP1.mLb.clN_peaks.narrowPeak | wc -l | awk -v OFS='	' '{ print "SRR4000468_REP1.mLb.clN_peaks", $1 }' | cat merged_library_peak_count_header.txt - > SRR4000468_REP1.mLb.clN_peaks.count_mqc.tsv
cat merged_library_frip_score_header.txt SRR4000468_REP1.FRiP.txt > SRR4000468_REP1.mLb.clN_peaks.FRiP_mqc.tsv

cat <<-END_VERSIONS > versions.yml
"NFCORE_ATACSEQ:ATACSEQ:MERGED_LIBRARY_CALL_ANNOTATE_PEAKS:MULTIQC_CUSTOM_PEAKS":
    sed: $(echo $(sed --version 2>&1) | sed 's/^.*GNU sed) //; s/ .*$//')
END_VERSIONS
