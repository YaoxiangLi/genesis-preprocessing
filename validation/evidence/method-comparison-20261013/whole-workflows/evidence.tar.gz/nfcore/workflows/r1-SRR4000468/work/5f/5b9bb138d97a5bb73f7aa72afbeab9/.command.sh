#!/bin/bash -euo pipefail
ataqv \
    --ignore-read-groups \
    --mitochondrial-reference-name Mt \
    --peak-file SRR4000468_REP1.mLb.clN_peaks.narrowPeak \
    --tss-file arabidopsis.gtf.asset.gtf.tss.bed \
     \
    --autosomal-reference-file reference.fa.autosomes.txt \
    --metrics-file "SRR4000468_REP1.ataqv.json" \
    --threads 14 \
    --name SRR4000468_REP1 \
    NA \
    SRR4000468_REP1.mLb.mkD.sorted.bam

cat <<-END_VERSIONS > versions.yml
"NFCORE_ATACSEQ:ATACSEQ:MERGED_LIBRARY_ATAQV_ATAQV":
    ataqv: $( ataqv --version )
END_VERSIONS
