#!/bin/bash -euo pipefail
READS_IN_PEAKS=$(intersectBed -a SRR4000468_REP1.mLb.clN.sorted.bam -b SRR4000468_REP1.mLb.clN_peaks.narrowPeak -bed -c -f 0.20 | awk -F '	' '{sum += $NF} END {print sum}')
samtools flagstat SRR4000468_REP1.mLb.clN.sorted.bam > SRR4000468_REP1.mLb.clN.sorted.bam.flagstat
grep 'mapped (' SRR4000468_REP1.mLb.clN.sorted.bam.flagstat | grep -v "primary" | awk -v a="$READS_IN_PEAKS" -v OFS='	' '{print "SRR4000468_REP1", a/$1}' > SRR4000468_REP1.FRiP.txt

cat <<-END_VERSIONS > versions.yml
"NFCORE_ATACSEQ:ATACSEQ:MERGED_LIBRARY_CALL_ANNOTATE_PEAKS:FRIP_SCORE":
    bedtools: $(bedtools --version | sed -e "s/bedtools v//g")
    samtools: $(echo $(samtools --version 2>&1) | sed 's/^.*samtools //; s/Using.*$//')
END_VERSIONS
