#!/bin/bash -euo pipefail
samtools \
    stats \
    --threads 14 \
    --reference reference.fa \
    SRR4000469_REP1_T1.Lb.sorted.bam \
    > SRR4000469_REP1_T1.Lb.sorted.bam.stats

cat <<-END_VERSIONS > versions.yml
"NFCORE_ATACSEQ:ATACSEQ:FASTQ_ALIGN_BWA:BAM_SORT_STATS_SAMTOOLS:BAM_STATS_SAMTOOLS:SAMTOOLS_STATS":
    samtools: $(echo $(samtools --version 2>&1) | sed 's/^.*samtools //; s/Using.*$//')
END_VERSIONS
