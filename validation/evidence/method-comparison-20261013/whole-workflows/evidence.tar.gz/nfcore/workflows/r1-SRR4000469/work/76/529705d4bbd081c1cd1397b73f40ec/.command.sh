#!/bin/bash -euo pipefail
bedGraphToBigWig \
    SRR4000469_REP1.mLb.clN.bedGraph \
    reference.fa.sizes \
    SRR4000469_REP1.mLb.clN.bigWig

cat <<-END_VERSIONS > versions.yml
"NFCORE_ATACSEQ:ATACSEQ:MERGED_LIBRARY_BAM_TO_BIGWIG:UCSC_BEDGRAPHTOBIGWIG":
    ucsc: 445
END_VERSIONS
