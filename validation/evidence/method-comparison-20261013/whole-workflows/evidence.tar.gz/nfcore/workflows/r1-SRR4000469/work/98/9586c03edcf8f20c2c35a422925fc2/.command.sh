#!/bin/bash -euo pipefail
INDEX=`find -L ./ -name "*.amb" | sed 's/\.amb$//'`

bwa mem \
    -M  -R '@RG\tID:SRR4000469_REP1_T1\tSM:SRR4000469_REP1\tPL:ILLUMINA\tLB:SRR4000469_REP1_T1\tPU:1' \
    -t 14 \
    $INDEX \
    SRR4000469_R1.fastq.gz SRR4000469_R2.fastq.gz \
    | samtools view -bhS -F 0x0100 -O BAM --threads 14 -o SRR4000469_REP1_T1.Lb.bam -

cat <<-END_VERSIONS > versions.yml
"NFCORE_ATACSEQ:ATACSEQ:FASTQ_ALIGN_BWA:BWA_MEM":
    bwa: $(echo $(bwa 2>&1) | sed 's/^.*Version: //; s/Contact:.*$//')
    samtools: $(echo $(samtools --version 2>&1) | sed 's/^.*samtools //; s/Using.*$//')
END_VERSIONS
