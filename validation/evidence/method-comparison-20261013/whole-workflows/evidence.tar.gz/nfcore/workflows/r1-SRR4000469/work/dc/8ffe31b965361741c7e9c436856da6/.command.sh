#!/bin/bash -euo pipefail
SCALE_FACTOR=$(grep '[0-9] mapped (' SRR4000469_REP1.mLb.clN.sorted.bam.flagstat | awk '{print 1000000/$1}')
echo $SCALE_FACTOR > SRR4000469_REP1.mLb.clN.scale_factor.txt

bedtools \
    genomecov \
    -ibam SRR4000469_REP1.mLb.clN.sorted.bam \
    -bg \
    -scale $SCALE_FACTOR \
    -pc \
     \
> tmp.bg

bedtools sort -i tmp.bg > SRR4000469_REP1.mLb.clN.bedGraph

cat <<-END_VERSIONS > versions.yml
"NFCORE_ATACSEQ:ATACSEQ:MERGED_LIBRARY_BAM_TO_BIGWIG:BEDTOOLS_GENOMECOV":
    bedtools: $(bedtools --version | sed -e "s/bedtools v//g")
END_VERSIONS
