#!/bin/bash -euo pipefail
picard \
    -Xmx65536M \
    MarkDuplicates \
    --ASSUME_SORTED true --REMOVE_DUPLICATES false --VALIDATION_STRINGENCY LENIENT --TMP_DIR tmp \
    --INPUT SRR4000469_REP1.mLb.sorted.bam \
    --OUTPUT SRR4000469_REP1.mLb.mkD.sorted.bam \
    --REFERENCE_SEQUENCE reference.fa \
    --METRICS_FILE SRR4000469_REP1.mLb.mkD.sorted.MarkDuplicates.metrics.txt

cat <<-END_VERSIONS > versions.yml
"NFCORE_ATACSEQ:ATACSEQ:MERGED_LIBRARY_MARKDUPLICATES_PICARD:PICARD_MARKDUPLICATES":
    picard: $(echo $(picard MarkDuplicates --version 2>&1) | grep -o 'Version:.*' | cut -f2- -d:)
END_VERSIONS
