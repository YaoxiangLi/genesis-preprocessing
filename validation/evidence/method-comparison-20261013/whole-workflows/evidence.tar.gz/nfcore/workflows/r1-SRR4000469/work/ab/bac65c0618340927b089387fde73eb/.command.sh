#!/bin/bash -euo pipefail
picard \
    -Xmx65536M \
    CollectMultipleMetrics \
    --VALIDATION_STRINGENCY LENIENT --TMP_DIR tmp \
    --INPUT SRR4000469_REP1.mLb.clN.sorted.bam \
    --OUTPUT SRR4000469_REP1.mLb.clN.CollectMultipleMetrics \
    --REFERENCE_SEQUENCE reference.fa

cat <<-END_VERSIONS > versions.yml
"NFCORE_ATACSEQ:ATACSEQ:MERGED_LIBRARY_PICARD_COLLECTMULTIPLEMETRICS":
    picard: $(picard CollectMultipleMetrics --version 2>&1 | grep -o 'Version.*' | cut -f2- -d:)
END_VERSIONS
